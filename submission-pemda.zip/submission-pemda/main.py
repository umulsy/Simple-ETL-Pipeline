# main.py

from utils.extract import scrape_all_products
from utils.transform import transform_data
from utils.load import save_to_csv, save_to_google_sheets

# Ganti dengan file dan ID spreadsheet kamu
SERVICE_ACCOUNT_FILE = 'google-sheets-api.json'
SPREADSHEET_ID = '1wR1RR5qf79pgz-D1gX5IuN2SBffXlbFh7D-N-3rN38o'

def main():
    """Fungsi utama untuk menjalankan proses ETL"""

    # ---------------------- Extract ----------------------
    print("[ETL] Memulai proses scraping...")
    url = 'https://fashion-studio.dicoding.dev/'
    all_products_data = scrape_all_products(url)

    if not all_products_data:
        print("[ETL] Tidak ada data yang berhasil di-scrape.")
        return

    print(f"[ETL] Total produk berhasil di-scrape: {len(all_products_data)}")

    # ---------------------- Transform ----------------------
    print("\n[ETL] Memulai proses transformasi data...")

    df_clean = transform_data(all_products_data)
    if df_clean is None or df_clean.empty:
        print("[ETL] Gagal melakukan transformasi data.")
        return

    print("[ETL] Transformasi data selesai.\n")
    print(df_clean.head())

    # ---------------------- Load ----------------------
    print("\n[ETL] Memulai proses penyimpanan data...")

    try:
        save_to_csv(df_clean.to_dict(orient="records"), filename="products.csv")
        save_to_google_sheets(df_clean.to_dict(orient="records"), SERVICE_ACCOUNT_FILE, SPREADSHEET_ID)
        print("[ETL] Semua data berhasil disimpan.")
    except Exception as e:
        print(f"[ETL] Terjadi kesalahan saat menyimpan data: {e}")

    print("\n[ETL] Proses ETL selesai.")

if __name__ == '__main__':
    main()
