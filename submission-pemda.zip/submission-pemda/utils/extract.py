import requests
from bs4 import BeautifulSoup
from datetime import datetime


def get_page_content(url):
    """Mengambil konten HTML dari URL target."""
    try:
        response = requests.get(url)
        response.raise_for_status()
        return response.text
    except requests.RequestException as e:
        print(f"[ERROR] Gagal mengambil halaman {url}: {e}")
        return None


def extract_product_details(card):
    """Ekstrak informasi produk dari 1 elemen kartu produk (collection-card)."""
    try:
        details = card.find('div', class_='product-details')
        if not details:
            print("[WARNING] Elemen product-details tidak ditemukan.")
            return None

        # Ambil judul
        title_tag = details.find('h3', class_='product-title')
        title = title_tag.get_text(strip=True) if title_tag else None

        # Ambil harga dari span.price ATAU p.price
        price_tag = details.find('span', class_='price') or details.find('p', class_='price')
        price = price_tag.get_text(strip=True) if price_tag else None

        # Ambil info tambahan dari <p> lainnya
        info_paragraphs = [
            p.get_text(strip=True)
            for p in details.find_all('p')
            if 'price' not in (p.get('class') or [])
        ]

        product = {
            "Title": title,
            "Price": price,
            "Rating": info_paragraphs[0] if len(info_paragraphs) > 0 else None,
            "Colors": info_paragraphs[1] if len(info_paragraphs) > 1 else None,
            "Size": info_paragraphs[2] if len(info_paragraphs) > 2 else None,
            "Gender": info_paragraphs[3] if len(info_paragraphs) > 3 else None,
            "Timestamp": datetime.now().isoformat()
        }

        return product

    except Exception as e:
        print(f"[ERROR] Gagal memproses produk: {e}")
        return None


def scrape_all_products(base_url, max_pages=10):
    """Scrape seluruh produk dari beberapa halaman katalog."""
    all_products = []

    for page in range(1, max_pages + 1):
        url = base_url if page == 1 else f"{base_url}/page{page}"
        print(f"[INFO] Scraping: {url}")

        html = get_page_content(url)
        if not html:
            print(f"[WARNING] Konten kosong dari {url}, lanjut.")
            continue

        soup = BeautifulSoup(html, "html.parser")
        cards = soup.select("div.collection-card")

        if not cards:
            print(f"[INFO] Tidak ada produk di halaman {page}. Stop.")
            break

        for card in cards:
            product = extract_product_details(card)
            if product:
                all_products.append(product)

    print(f"[INFO] Total produk diambil: {len(all_products)}")
    return all_products
