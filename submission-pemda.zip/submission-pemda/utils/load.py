# load.py

import pandas as pd
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build


def save_to_csv(products: list[dict], filename="products.csv"):
    """Simpan list produk ke file CSV lokal."""
    try:
        df = pd.DataFrame(products)
        df.to_csv(filename, index=False, encoding='utf-8')
        print(f"[INFO] Data berhasil disimpan ke file: {filename}")
    except Exception as e:
        print(f"[ERROR] Gagal menyimpan ke CSV: {e}")


def save_to_google_sheets(products: list[dict], service_account_file: str, spreadsheet_id: str, range_name="Sheet1!A1"):
    """Simpan list produk ke Google Sheets."""
    try:
        # Konversi list produk ke DataFrame
        df = pd.DataFrame(products)

        # Autentikasi Google API
        credentials = Credentials.from_service_account_file(
            service_account_file,
            scopes=["https://www.googleapis.com/auth/spreadsheets", "https://www.googleapis.com/auth/drive"]
        )
        service = build('sheets', 'v4', credentials=credentials)

        # Convert kolom 'Timestamp' jadi string (jika ada)
        if 'Timestamp' in df.columns:
            df['Timestamp'] = df['Timestamp'].astype(str)

        # Siapkan data (header + isi)
        values = [df.columns.tolist()] + df.values.tolist()
        body = {'values': values}

        # Kirim ke Google Sheets
        service.spreadsheets().values().update(
            spreadsheetId=spreadsheet_id,
            range=range_name,
            valueInputOption="RAW",
            body=body
        ).execute()

        print("[INFO] Data berhasil disimpan ke Google Sheets.")

    except Exception as e:
        print(f"[ERROR] Gagal menyimpan ke Google Sheets: {e}")
