# transform.py

import pandas as pd

# ---------- 1. Konversi Awal ke DataFrame ----------
def to_dataframe(raw_data):
    """Mengubah list of dict menjadi DataFrame."""
    if not raw_data:
        print("[WARNING] Data kosong, tidak dapat diubah menjadi DataFrame.")
        return None
    return pd.DataFrame(raw_data)


# ---------- 2. Pembersihan Nilai Tidak Valid ----------
def remove_invalid_entries(df):
    """Menghapus entri tidak valid dari kolom penting."""
    invalid_patterns = {
        "Title": ["Unknown Product"],
        "Rating": ["Invalid Rating / 5", "Not Rated"],
        "Price": ["Price Unavailable", None]
    }

    df = df[~df['Title'].isin(invalid_patterns['Title'])]
    df = df[~df['Rating'].isin(invalid_patterns['Rating'])]
    df = df[~df['Price'].isin(invalid_patterns['Price'])]

    return df


# ---------- 3. Membersihkan & Mengonversi Kolom ----------
def clean_columns(df, exchange_rate=16000):
    """Membersihkan dan mengubah format kolom ke bentuk siap analisis."""

    # Rating: ekstrak angka seperti "4.8 / 5" -> 4.8
    df['Rating'] = df['Rating'].str.extract(r'([0-9.]+)')

    # Price: hilangkan tanda $, koma, ubah ke float lalu konversi ke Rupiah
    df['Price'] = df['Price'].replace({r'\$': '', r',': ''}, regex=True)
    df['Price'] = pd.to_numeric(df['Price'], errors='coerce') * exchange_rate

    # Colors: ambil angka dari teks seperti "5 Colors"
    df['Colors'] = df['Colors'].replace(r'\D+', '', regex=True)
    df['Colors'] = pd.to_numeric(df['Colors'], errors='coerce')

    # Size & Gender: hilangkan prefix
    df['Size'] = df['Size'].str.replace('Size: ', '', regex=False)
    df['Gender'] = df['Gender'].str.replace('Gender: ', '', regex=False)

    return df


# ---------- 4. Finalisasi Data ----------
def finalize_dataframe(df):
    """Hapus nilai kosong dan duplikat, pastikan tipe data sesuai."""

    df = df.dropna()
    df = df.drop_duplicates()

    # Pastikan semua tipe data sudah sesuai
    df = df.astype({
        "Title": "object",
        "Rating": "float64",
        "Price": "float64",
        "Colors": "int64",
        "Size": "object",
        "Gender": "object"
    })

    return df


# ---------- 5. Fungsi Utama ----------
def transform_data(raw_data, exchange_rate=16000):
    """Fungsi utama untuk transformasi data lengkap dari hasil scraping."""
    df = to_dataframe(raw_data)
    if df is None:
        return None

    df = remove_invalid_entries(df)
    df = clean_columns(df, exchange_rate)
    df = finalize_dataframe(df)
    return df
