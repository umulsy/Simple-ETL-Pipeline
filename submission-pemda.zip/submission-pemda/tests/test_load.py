# test_load.py

import unittest
from unittest.mock import patch, Mock
import pandas as pd

from utils.load import save_to_csv, save_to_google_sheets

class TestSaveFunctions(unittest.TestCase):

    def setUp(self):
        """Menyiapkan data list of dict sebagai mock"""
        self.mock_data = [
            {
                'Title': 'T-shirt 1',
                'Price': '$123.45',
                'Rating': '4.5',
                'Colors': '3',
                'Size': 'M',
                'Gender': 'Men',
                'Timestamp': '2025-04-01T12:00:00'
            },
            {
                'Title': 'T-shirt 2',
                'Price': '$150.00',
                'Rating': '4.7',
                'Colors': '2',
                'Size': 'L',
                'Gender': 'Women',
                'Timestamp': '2025-04-02T12:00:00'
            }
        ]

    # ---------- Test save_to_csv ----------
    @patch('utils.load.pd.DataFrame.to_csv')
    def test_save_to_csv_success(self, mock_to_csv):
        """Menguji apakah to_csv dipanggil dengan benar"""
        save_to_csv(self.mock_data, "products.csv")
        mock_to_csv.assert_called_once_with("products.csv", index=False, encoding='utf-8')

    @patch('utils.load.pd.DataFrame.to_csv')
    def test_save_to_csv_error(self, mock_to_csv):
        """Menguji apabila terjadi error saat menyimpan ke CSV"""
        mock_to_csv.side_effect = Exception("Simulated CSV error")
        save_to_csv(self.mock_data, "products.csv")  # Akan print error, tidak raise

    # ---------- Test save_to_google_sheets ----------
    @patch('utils.load.build')
    @patch('utils.load.Credentials.from_service_account_file')
    def test_save_to_google_sheets_success(self, mock_creds, mock_build):
        """Menguji Google Sheets disimpan dengan benar"""
        mock_service = Mock()
        mock_sheets = mock_service.spreadsheets.return_value
        mock_values = mock_sheets.values.return_value

        mock_build.return_value = mock_service

        save_to_google_sheets(
            self.mock_data,
            service_account_file="dummy.json",
            spreadsheet_id="dummy_id"
        )

        mock_values.update.assert_called_once()

    @patch('utils.load.build', side_effect=Exception("Google Sheets API error"))
    @patch('utils.load.Credentials.from_service_account_file')
    def test_save_to_google_sheets_error(self, mock_creds, mock_build):
        """Menguji error saat menyimpan ke Google Sheets"""
        save_to_google_sheets(
            self.mock_data,
            service_account_file="dummy.json",
            spreadsheet_id="dummy_id"
        )  # Akan print error, tidak raise


if __name__ == '__main__':
    unittest.main()
