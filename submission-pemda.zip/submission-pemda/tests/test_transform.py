# extract_transform.py

import pandas as pd
from utils.transform import transform_data

def test_transform_data_types():
    data = [
        {
            'Title': 'Item A',
            'Price': '$12.99',
            'Rating': '4.2 / 5',
            'Colors': '5 colors',
            'Size': 'Size: M',
            'Gender': 'Gender: Unisex',
            'Timestamp': '2025-05-19T00:00:00'
        }
    ]
    transformed = transform_data(data)

    assert transformed['Price'].dtype == 'float64'
    assert transformed['Rating'].dtype == 'float64'
    assert transformed['Colors'].dtype == 'int64'
    assert transformed['Size'].dtype == 'object'
    assert transformed['Gender'].dtype == 'object'


def test_transform_data_removes_nulls_and_duplicates():
    data = [
        {
            'Title': 'Item A',
            'Price': '$10.00',
            'Rating': '4.0 / 5',
            'Colors': '3 colors',
            'Size': 'Size: S',
            'Gender': 'Gender: Male',
            'Timestamp': '2025-05-19T00:00:00'
        },
        {
            'Title': 'Item A',  # Duplicate
            'Price': '$10.00',
            'Rating': '4.0 / 5',
            'Colors': '3 colors',
            'Size': 'Size: S',
            'Gender': 'Gender: Male',
            'Timestamp': '2025-05-19T00:00:00'
        },
        {
            'Title': 'Unknown Product',  # Invalid title
            'Price': '$15.00',
            'Rating': 'Not Rated',
            'Colors': '2 colors',
            'Size': 'Size: M',
            'Gender': 'Gender: Female',
            'Timestamp': '2025-05-19T00:00:00'
        }
    ]

    transformed = transform_data(data)

    # Hanya 1 baris yang valid dan unik harus tersisa
    assert len(transformed) == 1
