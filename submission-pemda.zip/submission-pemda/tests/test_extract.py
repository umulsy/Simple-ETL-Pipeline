# test_extracts.py

import unittest
from unittest.mock import patch
from bs4 import BeautifulSoup
import requests

from utils.extract import (
    get_page_content,
    extract_product_details,
    scrape_all_products
)

class TestExtracts(unittest.TestCase):

    def setUp(self):
        self.sample_html = """
        <div class="collection-card">
            <div class="product-details">
                <h3 class="product-title">T-shirt 1</h3>
                <span class="price">$100.00</span>
                <p>Rating: ⭐ 4.8 / 5</p>
                <p>5 Colors</p>
                <p>Size: M</p>
                <p>Gender: Men</p>
            </div>
        </div>
        """
        self.soup = BeautifulSoup(self.sample_html, 'html.parser')
        self.card = self.soup.find('div', class_='collection-card')

    # ---------------- get_page_content ----------------

    @patch('requests.get')
    def test_get_page_content_success(self, mock_get):
        mock_get.return_value.status_code = 200
        mock_get.return_value.text = "<html><body>Test Content</body></html>"

        result = get_page_content("https://example.com")
        self.assertIn("Test Content", result)

    @patch('requests.get')
    def test_get_page_content_failure(self, mock_get):
        mock_get.return_value.status_code = 404
        mock_get.return_value.raise_for_status.side_effect = requests.exceptions.HTTPError()
        result = get_page_content("https://example.com")
        self.assertIsNone(result)

    @patch('requests.get', side_effect=requests.exceptions.Timeout)
    def test_get_page_content_timeout(self, mock_get):
        result = get_page_content("https://example.com")
        self.assertIsNone(result)

    # ---------------- extract_product_details ----------------

    def test_extract_product_details(self):
        result = extract_product_details(self.card)
        self.assertEqual(result['Title'], 'T-shirt 1')
        self.assertEqual(result['Price'], '$100.00')
        self.assertEqual(result['Rating'], 'Rating: ⭐ 4.8 / 5')
        self.assertEqual(result['Colors'], '5 Colors')
        self.assertEqual(result['Size'], 'Size: M')
        self.assertEqual(result['Gender'], 'Gender: Men')
        self.assertIn('Timestamp', result)

    def test_extract_product_details_missing_price(self):
        html = """
        <div class="collection-card">
            <div class="product-details">
                <h3 class="product-title">T-shirt X</h3>
                <p>Rating: ⭐ 4.0 / 5</p>
                <p>4 Colors</p>
                <p>Size: L</p>
                <p>Gender: Women</p>
            </div>
        </div>
        """
        soup = BeautifulSoup(html, 'html.parser')
        card = soup.find('div', class_='collection-card')
        result = extract_product_details(card)
        self.assertIsNone(result['Price'])

    # ---------------- scrape_all_products ----------------

    @patch('utils.extract.get_page_content')
    def test_scrape_all_products_empty_page(self, mock_get):
        mock_get.return_value = "<html><body>No products here</body></html>"
        result = scrape_all_products("https://example.com", max_pages=1)
        self.assertEqual(len(result), 0)

    @patch('utils.extract.get_page_content', return_value=None)
    def test_scrape_all_products_failed_fetch(self, mock_get):
        result = scrape_all_products("https://example.com", max_pages=1)
        self.assertEqual(result, [])

    @patch('utils.extract.get_page_content')
    def test_scrape_all_products_one_product(self, mock_get):
        mock_get.return_value = self.sample_html
        result = scrape_all_products("https://example.com", max_pages=1)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]['Title'], 'T-shirt 1')


if __name__ == "__main__":
    unittest.main()
